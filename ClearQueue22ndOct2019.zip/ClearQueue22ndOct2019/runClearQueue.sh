#!/bin/bash 
java -jar ConfigureServer.jar

